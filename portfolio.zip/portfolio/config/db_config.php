<?php
// Configurações do Banco de Dados
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', ''); // Deixe vazio se não tiver senha no XAMPP
define('DB_NAME', 'portfolio_arthur');
define('DB_CHARSET', 'utf8mb4');

// Classe de Conexão com o Banco de Dados
class Database {
    private $conn;
    private $host = DB_HOST;
    private $user = DB_USER;
    private $pass = DB_PASS;
    private $dbname = DB_NAME;
    private $charset = DB_CHARSET;
    
    // Conectar ao banco de dados
    public function connect() {
        $this->conn = null;
        
        try {
            $dsn = "mysql:host=" . $this->host . ";dbname=" . $this->dbname . ";charset=" . $this->charset;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            
            $this->conn = new PDO($dsn, $this->user, $this->pass, $options);
            
        } catch(PDOException $e) {
            echo "Erro na conexão: " . $e->getMessage();
        }
        
        return $this->conn;
    }
    
    // Fechar conexão
    public function disconnect() {
        $this->conn = null;
    }
}

// Função auxiliar para obter conexão
function getConnection() {
    $database = new Database();
    return $database->connect();
}
?>