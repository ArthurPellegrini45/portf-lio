<?php
// Habilitar CORS para permitir requisições do frontend
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

// Se for requisição OPTIONS, retornar sucesso
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Incluir arquivo de configuração
require_once '../config/db_config.php';

// Verificar se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Obter dados JSON do corpo da requisição
    $data = json_decode(file_get_contents("php://input"), true);
    
    // Validar dados recebidos
    if (
        !empty($data['name']) && 
        !empty($data['email']) && 
        !empty($data['subject']) && 
        !empty($data['message'])
    ) {
        
        try {
            // Conectar ao banco de dados
            $conn = getConnection();
            
            // Sanitizar dados
            $nome = htmlspecialchars(strip_tags($data['name']));
            $email = filter_var($data['email'], FILTER_SANITIZE_EMAIL);
            $telefone = isset($data['phone']) ? htmlspecialchars(strip_tags($data['phone'])) : null;
            $assunto = htmlspecialchars(strip_tags($data['subject']));
            $mensagem = htmlspecialchars(strip_tags($data['message']));
            
            // Validar email
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'message' => 'Email inválido!'
                ]);
                exit();
            }
            
            // Preparar SQL para inserção
            $sql = "INSERT INTO contatos (nome, email, telefone, assunto, mensagem, status) 
                    VALUES (:nome, :email, :telefone, :assunto, :mensagem, 'novo')";
            
            $stmt = $conn->prepare($sql);
            
            // Bind dos parâmetros
            $stmt->bindParam(':nome', $nome);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':telefone', $telefone);
            $stmt->bindParam(':assunto', $assunto);
            $stmt->bindParam(':mensagem', $mensagem);
            
            // Executar query
            if ($stmt->execute()) {
                http_response_code(201);
                echo json_encode([
                    'success' => true,
                    'message' => 'Mensagem enviada com sucesso! Entrarei em contato em breve.',
                    'id' => $conn->lastInsertId()
                ]);
            } else {
                http_response_code(500);
                echo json_encode([
                    'success' => false,
                    'message' => 'Erro ao enviar mensagem. Tente novamente.'
                ]);
            }
            
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Erro no servidor: ' . $e->getMessage()
            ]);
        }
        
    } else {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Por favor, preencha todos os campos obrigatórios!'
        ]);
    }
    
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    
    // Endpoint para listar contatos (CRUD - Read)
    try {
        $conn = getConnection();
        
        $sql = "SELECT id, nome, email, telefone, assunto, 
                LEFT(mensagem, 100) as mensagem_preview, 
                data_envio, status 
                FROM contatos 
                ORDER BY data_envio DESC 
                LIMIT 50";
        
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        
        $contatos = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        http_response_code(200);
        echo json_encode([
            'success' => true,
            'data' => $contatos,
            'total' => count($contatos)
        ]);
        
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Erro ao buscar contatos: ' . $e->getMessage()
        ]);
    }
    
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Método não permitido!'
    ]);
}
?>