// Configuração da API
const API_URL = 'http://localhost/portfolio/api/process_contact.php';

// Função para enviar formulário de contato
async function submitContactForm(formData) {
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
        });

        const result = await response.json();
        return result;

    } catch (error) {
        console.error('Erro na requisição:', error);
        return {
            success: false,
            message: 'Erro ao conectar com o servidor. Verifique sua conexão.'
        };
    }
}

// Event listener para o formulário de contato
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Coletar dados do formulário
            const formData = {
                name: document.getElementById('name').value.trim(),
                email: document.getElementById('email').value.trim(),
                phone: document.getElementById('phone').value.trim(),
                subject: document.getElementById('subject').value.trim(),
                message: document.getElementById('message').value.trim()
            };

            // Validação básica no frontend
            if (!formData.name || !formData.email || !formData.subject || !formData.message) {
                showMessage('Por favor, preencha todos os campos obrigatórios!', 'error');
                return;
            }

            // Validar email
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(formData.email)) {
                showMessage('Por favor, insira um email válido!', 'error');
                return;
            }

            // Desabilitar botão de envio
            const submitBtn = contactForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.disabled = true;
            submitBtn.textContent = 'Enviando...';

            // Enviar dados para o servidor
            const result = await submitContactForm(formData);

            // Reabilitar botão
            submitBtn.disabled = false;
            submitBtn.textContent = originalText;

            // Mostrar mensagem de resultado
            if (result.success) {
                showMessage(result.message, 'success');
                contactForm.reset();
                
                // Salvar também localmente para backup
                saveLocalBackup(formData);
                
            } else {
                showMessage(result.message || 'Erro ao enviar mensagem. Tente novamente.', 'error');
            }
        });
    }
});

// Função para exibir mensagens
function showMessage(message, type) {
    const successMessage = document.getElementById('successMessage');
    
    if (successMessage) {
        successMessage.textContent = message;
        successMessage.style.display = 'block';
        
        // Mudar cor baseado no tipo
        if (type === 'error') {
            successMessage.style.background = '#ef4444';
        } else {
            successMessage.style.background = '#10b981';
        }

        // Esconder mensagem após 5 segundos
        setTimeout(() => {
            successMessage.style.display = 'none';
        }, 5000);
    }
}

// Função para salvar backup local (localStorage)
function saveLocalBackup(formData) {
    try {
        let contactHistory = JSON.parse(localStorage.getItem('contactHistory') || '[]');
        
        formData.timestamp = new Date().toISOString();
        contactHistory.push(formData);
        
        // Manter apenas os últimos 10 registros
        if (contactHistory.length > 10) {
            contactHistory = contactHistory.slice(-10);
        }
        
        localStorage.setItem('contactHistory', JSON.stringify(contactHistory));
        console.log('Backup local salvo com sucesso');
        
    } catch (error) {
        console.error('Erro ao salvar backup local:', error);
    }
}

// Função para buscar todos os contatos (Admin)
async function getAllContacts() {
    try {
        const response = await fetch(API_URL, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }
        });

        const result = await response.json();
        
        if (result.success) {
            console.log('Contatos recuperados:', result.data);
            return result.data;
        } else {
            console.error('Erro ao buscar contatos:', result.message);
            return [];
        }

    } catch (error) {
        console.error('Erro na requisição:', error);
        return [];
    }
}

// Função para exibir contatos (útil para área administrativa)
function displayContacts(contacts) {
    console.table(contacts);
    
    contacts.forEach(contact => {
        console.log(`
            ID: ${contact.id}
            Nome: ${contact.nome}
            Email: ${contact.email}
            Assunto: ${contact.assunto}
            Data: ${contact.data_envio}
            Status: ${contact.status}
            -------------------
        `);
    });
}

// Exemplo de uso (descomente para testar)
// getAllContacts().then(contacts => displayContacts(contacts));